let a = 100
let b = true

setTimeout(() => {
 	console.log("66666")
 },0)

function test(){
	console.log("test执行了")
}

test()
console.log("1")
console.log("2")
console.log("3")
console.log("4")
console.log("5")
console.log("6")