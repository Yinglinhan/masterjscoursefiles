// 方法执行完返回的是什么 
// 如果需要传入函数 回调函数的返回值的意义
// 是否会修改调用方法的数组

const { fn } = require("moment")

//

let arr = [2,'三木',true]
arr.forEach(function(ele){

})


test(fn){
  //xxxxx
  fn(a,b,c)
}