// function a(){
// 	return 1
// }
// var a = function (){
// 	return 1;
// }

// var a = () => 1
// var a = () => {
// 	return 1;
// }

// function b(x){
// 	return x
// }
// var b = x => x
var b = x => {
	return  x
}



// function c(x,y){
// 	return x + y
// }

var c = (x,y) => x + y

// function d(x,y,z){
	
// 	var result = x + y + z
// 	return result
	
// }
var d = (x,y,z) => {
	var result = x + y + z
	return result
}

