
// function go(){

// 	console.log('我是go函数')
// }

// function test(f){
// 	f()
// }

// test(go)

// function test(f){
// 	f()
// }

// test(function(){console.log('我执行了')})
// // 或者
// test(() => console.log('我执行了'))

// const abc = function(){}


// 匿名函数  anonymous

// 立即执行函数
// immediately-invoked function expression  简称IIFE

(function(x){
	console.log(x)
})(1231232131)

!function(){}();
+function(){}();
-function(){}();
~function(){}();