// var a = 100
// a += 10 // 110
// a -= 20	// 90
// a *= 10	// 900
// a /= 4	// 225
// console.log(a)


// var x = 3;
// y = x++ + 3; // y -> 6 ,x -> 4
// console.log(x,y)


// var x = 100;
// y = --x + 1 ;// x -> 99 , y -> 100
// console.log(x,y)
// var a = 1
// y = ++a
// console.log(a)
// console.log(2)
// console.log(3)
