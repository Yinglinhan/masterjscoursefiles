
// 赋值运算符
// var abc

// console.log(abc = 1, abc)

// + - * / ** 算术运算符
// var a = 1 + 2
// var b = 3 ** 3
// b = 3 ** 5

// //复合赋值运算符
// // += -= *= /=  **=
// var a = 1
// // a += 3
// a = a + 3

// // 自增 自减 运算符
// // ++ --  加一  减一
// var y;
// var x = 3;
// // y = x--;
// y = x
// x -= 1


// console.log(x,y)

// 逗号运算符
// var a = 1, b = 3
// var c = (1,2,3,4)
// console.log(c)

// 可选链操作符  ?.

// var obj = { 
// 	name:'abc'
// }
// console.log(obj.type?.a)

// 扩展运算符
// var obj = { 
// 	name:'abc',
// 	age:18,
// 	child:{
// 		baby:'a'
// 	}
// }

// var obj2 = {
// 	...obj
// }
// // console.log(obj2)
// obj2.child.baby = 'b'
// console.log(obj)




