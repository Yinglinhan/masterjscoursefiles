// var a
// var b = 2
// var c 
// c = 'abc'
// var dog = {
// 	name:"xxx",
// 	species:"xx",
// 	age:5
// }
// dog.name = 'yyy'

// dog.age

// 1
// var a = 1; 
// var b = 2;
// var c = {name:'xxx'};

// var a = 1
// // 这个语句就不是表达式
// a = 3
// // 这个返回3 所以这个就是表达式

// var c = {
// 	name:"xxx"
// }
// // 这个不是表达式

// c.name 
// // 这个是表达式

// 1
// '100'
// true
// //这是表达式

// console.log(a = 4)




1 + 3

'好奇代码' + '的三木'


var obj = {
	name:'xyz'
}

true

obj.name = 'abc'

var a = 123

a = 456

a

a - 100