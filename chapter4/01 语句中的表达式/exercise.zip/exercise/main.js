
1 + 3

'好奇代码' + '的三木'


var obj = {
	name:'xyz'
}

true

obj.name = 'abc'

var a = 123

a = 456

a

a - 100