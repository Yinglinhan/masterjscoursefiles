// 1 === '1' // false

// 123 == '123' // true

// parseInt('110s') === 110 // true

// false == 0 // true

// true > false  // true

// NaN !== NaN  // true

// true == 12231 // false

// NaN < 1000 // false

// NaN >= 1000 //false


// // console.log(NaN != NaN)
// console.log(true == 12231)

// 1 !== '1'

// 1. 说出严格相等 和严格不等于相等和不等的比较运算符的区别
// 2. 任何数字类型数据 转换成布尔值 都是true ，这个说法对么？哪里不对？
// 3. undefined 转换成数字类型是 0，对么？  NaN