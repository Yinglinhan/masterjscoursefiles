

var friend = 'A'

switch (friend) {
	case "A":
		console.log("准备白开水");
		break;
	case "B":
		console.log("准备茶");
		break;
	case "C":
		console.log("准备果汁");
		break;
	default:
		console.log("准备可乐")
}

var a = 10
if(a > 100){
	console.log(100)
}else if(a < 60){
	console.log(666)
}