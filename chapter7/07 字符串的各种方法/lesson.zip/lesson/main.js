/* 
length

split

includes

trim

toUpperCase

toLowerCase

slice()

substring()

indexOf()

lastIndexOf()

*/
const str = 'The quick brown fox jumps over the lazy dog.';
const chars = str.split(' ');
console.log(chars)
// join 数组方法
/* 

fromCharCode()

charCodeAt()

codePointAt()

charAt()

concat()

startWith()

endsWith()

includes()

repeat()

padStart()

padEnd()

*/

/* 

match

search

replace

split

*/