// number  string  boolean
// 不是对象 
// console.log("好奇代码的三木".length)
// console.log("好奇代码的三木".length)

// Number  String  Boolean  包装类型
/* 
原型方法
toFixed  让某个数 保有几位小数

toExponential

toPrecision

静态方法
Number.isInteger() 
*/

// 三个包装类 直接使用可以转换数据类型
console.log(String(1),1)
console.log(Boolean({}),{})
console.log(Number('12312s'),1)